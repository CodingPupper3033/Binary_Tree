// Node
/*
public class BinaryTreeNodeOld<E> {
    private BinaryTreeNodeOld<E> parent;
    private E root;
    private BinaryTreeNodeOld<E> left;
    private BinaryTreeNodeOld<E> right;

    public BinaryTreeNodeOld(BinaryTreeNodeOld<E> parent, E root, BinaryTreeNodeOld<E> left, BinaryTreeNodeOld<E> right) {
        setParent(parent);
        setRoot(root);
        setLeft(left);
        setRight(right);
    }

    public BinaryTreeNodeOld(BinaryTree<E> parent, E root, BinaryTreeNodeOld<E> left, BinaryTreeNodeOld<E> right) {
        setParent(parent.root);
        setRoot(root);
        setLeft(left);
        setRight(right);
    }

    // Parent
    public BinaryTreeNodeOld<E> getParent() {
        return parent;
    }

    public void setParent(BinaryTreeNodeOld<E> parent) {
        this.parent = parent;
    }

    // Root
    public E get() {
        return root;
    }

    public void setRoot(E root) {
        this.root = root;
    }

    // Left
    public BinaryTreeNodeOld<E> getLeft() {
        return left;
    }

    public void setLeft(BinaryTreeNodeOld<E> left) {
        this.left = left;
    }

    // Right
    public BinaryTreeNodeOld<E> getRight() {
        return right;
    }

    public void setRight(BinaryTreeNodeOld<E> right) {
        this.right = right;
    }
}

 */
