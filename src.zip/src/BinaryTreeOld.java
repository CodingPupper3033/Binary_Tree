import java.util.NoSuchElementException;

public class BinaryTreeOld<E> {
    private BinaryTreeNode<E> root;

    public BinaryTreeOld() {
        root = null;
    }

    public BinaryTreeOld(E rootData) {
        this.root = new BinaryTreeNode<E>(rootData, null);
    }

    private BinaryTreeOld(BinaryTreeNode<E> root) {
        this.root = root;
    }

    public BinaryTreeOld(BinaryTreeOld<E> root) {
        this.root = root.root;
    }

    // Getters
    public E get() {
        if (root != null) {
            return root.getData();
        } else {
            throw(new NoSuchElementException());
        }
    }

    public E getNoError() {
        try {
            return get();
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    public BinaryTreeOld<E> getTree() {
        return new BinaryTreeOld<>(root);
    }

    public BinaryTreeOld<E> getParent() {
        return new BinaryTreeOld<>(root.parent);
    }

    public boolean hasParent() {
        return root.parent != null;
    }

    public E getLeft() {
        if (root.hasLeft()) {
            return root.getLeft().getData();
        } else {
            throw(new NoSuchElementException());
        }
    }

    public E getLeftNoError() {
        try {
            return getLeft();
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    public E getRight() {
        if (root.hasRight()) {
            return root.getRight().getData();
        } else {
            throw(new NoSuchElementException());
        }
    }

    public E getRightNoError() {
        try {
            return getRight();
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    public BinaryTreeOld getTreeLeft() {
        if (root.hasLeft()) {
            return new BinaryTreeOld(root.getLeft());
        } else {
            throw(new NoSuchElementException());
        }
    }

    public BinaryTreeOld getTreeRight() {
        if (root.hasRight()) {
            return new BinaryTreeOld(root.getRight());
        } else {
            throw(new NoSuchElementException());
        }
    }

    // Setters
    public void setRoot(BinaryTreeOld root) {
        setRoot(root.root);
    }

    private void setRoot(BinaryTreeNode<E> root) {
        root.parent = null;
        this.root = root;
    }

    public void setRoot(E data) {
        setRoot(new BinaryTreeNode<>(data, null));
    }

    public void setLeft(BinaryTreeOld left) {
        setLeft(left.root);
    }

    private void setLeft(BinaryTreeNode<E> left) {
        if (left != null) left.parent = root;
        root.setLeft(left);
    }

    public void setLeft(E data) {
        setLeft(new BinaryTreeNode<>(data, root));
    }

    public boolean hasLeft() {
        try {
            getLeft();
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void setRight(BinaryTreeOld right) {
        setRight(right.root);
    }

    private void setRight(BinaryTreeNode<E> right) {
        if (right != null) right.parent = root;
        root.setRight(right);
    }

    public void setRight(E data) {
        setRight(new BinaryTreeNode<>(data, root));
    }

    // Deleters
    public void deleteRoot() {
        this.root = null;
    }

    public void deleteLeft() {
        setLeft((BinaryTreeNode<E>) null);
    }

    public void deleteRight() {
        setRight((BinaryTreeNode<E>) null);
    }

    public boolean hasRight() {
        try {
            getRight();
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public boolean isLeftChild(E valueChild) {
        return (!hasLeft() && valueChild == null) || (hasLeft() && getLeft().equals(valueChild));
    }

    public boolean isRightChild(E valueChild) {
        return  (!hasRight() && valueChild == null) || (hasRight() && getRight().equals(valueChild));
    }

    private class BinaryTreeNode<E>{
        private BinaryTreeNode<E> parent;
        private E data;
        private BinaryTreeNode<E> left;
        private BinaryTreeNode<E> right;

        private BinaryTreeNode(E data, BinaryTreeNode<E> parent) {
            this(data,parent,null,null);
        }

        public BinaryTreeNode(E data, BinaryTreeNode<E> parent, BinaryTreeNode<E> left, BinaryTreeNode<E> right) {
            this.parent = parent;
            this.data = data;
            this.left = left;
            this.right = right;
        }

        public E getData() {
            return data;
        }

        public void setData(E data) {
            this.data = data;
        }

        public BinaryTreeNode<E> getParent() { return parent;}

        public BinaryTreeNode<E> getLeft() {
            return left;
        }

        public void setLeft(BinaryTreeNode<E> left) {
            this.left = left;
        }

        public BinaryTreeNode<E> getRight() {
            return right;
        }

        public void setRight(BinaryTreeNode<E> right) {
            this.right = right;
        }

        public void setLeft(E left) {
            setLeft(new BinaryTreeNode<>(left, this));
        }

        public void setRight(E right) {
            setRight(new BinaryTreeNode<>(right, this));
        }

        @Override
        public String toString() {
            return data.toString();
        }

        public boolean hasLeft() {
            return left != null;
        }

        public boolean hasRight() {
            return right != null;
        }

    }
}
