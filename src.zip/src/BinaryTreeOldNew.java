import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/*
public class BinaryTreeOldNew<E> {
    private BinaryTreeNodeOld<E> root;

    public BinaryTreeOldNew() {
        setRoot((E) null);
        setParent((BinaryTreeNodeOld<E>) null);
    }

    public BinaryTreeOldNew(E root) {
        this((BinaryTreeNodeOld<E>) null, root);
    }

    public BinaryTreeOldNew(BinaryTreeNodeOld<E> parent, E root) {
        setRoot(root);
        setParent(parent);
    }

    public BinaryTree(BinaryTree<E> tree) {
        setRoot(tree.getRoot());
    }

    private BinaryTreeOldNew(BinaryTreeNodeOld<E> root) {
        setRoot(root);
    }


    public String toString() {
        return toStringMultiLineMinimalNull();
    }

    public String toStringOneLine() {
        String out = "";
        // Has Root
        if (hasRoot()) {
            // This data
            out += getValue();

            // if leaf node, then return
            if (!hasLeft() && !hasRight())
                return out;

            // for left subtree
            out += '(';
            out += getLeft().toString();
            out += ')';

            // Right subtree
            out += '(';
            out += getRight().toString();
            out += ')';
        }
        return out;
    }

    public String toStringMultiLine() {
        char spaceChar = ' ';
        char topChar = '|';
        char leftChar = '┌';
        char rightChar = '┐';
        char middleChar = '─';
        char upChar = '┴';

        StringBuffer out = new StringBuffer();

        LinkedList<LinkedList<E>> lines = getLevelsList();

        // Get Max size of element
        int maxElementSize = 0;
        for (LinkedList<E> line : lines) {
            for (E item: line) {
                maxElementSize = Math.max(maxElementSize, String.valueOf(item).length());
            }
        }
        maxElementSize += (maxElementSize+1)%2;

        int lineNumb = 0;
        int numbLines = lines.size();
        int maxElementsRow = (int) Math.pow(2,numbLines-1);
        int maxStringLengthRow = maxElementsRow*maxElementSize + (maxElementsRow-1);

        for (LinkedList<E> line : lines) {
            StringBuffer lineOut = new StringBuffer();
            StringBuilder lineAbove = new StringBuilder();

            int itemOn = 0;
            for (E item: line) {
                StringBuilder itemString = new StringBuilder(String.valueOf(item));

                // Add spaces around to make it the same length
                int itemStringSize = itemString.length();

                double half = (maxElementSize-itemStringSize)/2.0;
                int amountFront = (int) Math.floor(half);
                int amountBack = (int) Math.ceil(half);

                itemString.insert(0,multiplyChar(amountFront, spaceChar)); // Front
                itemString.append(multiplyChar(amountBack, spaceChar)); // Back

                int elementsInRow = (int) Math.pow(2, lineNumb);

                int lineTotalSizeItems = line.size()*maxElementSize;
                int lineTotalSpaceSize = maxStringLengthRow-lineTotalSizeItems;
                double lineSpaceItem = (double)lineTotalSpaceSize/elementsInRow;
                int lineSpaceFront = (int)Math.floor(lineSpaceItem/2);
                int lineSpaceBack = (int)Math.ceil(lineSpaceItem/2);

                if (elementsInRow == 1) {
                    lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize/2, spaceChar) + topChar);
                } else
                    addLineAbove(spaceChar, leftChar, rightChar, middleChar, upChar, maxElementSize, lineAbove, itemOn, lineSpaceFront, lineSpaceBack);

                lineOut.append(multiplyChar(lineSpaceFront, ' ') + itemString + multiplyChar(lineSpaceBack, ' ')); // Remove

                itemOn++;
            }

            out.append(lineAbove + "\n");
            out.append(lineOut + "\n");
            lineNumb++;
        }

        if (out.length() > 0) out.deleteCharAt(out.length()-1);
        return out.toString();
    }

    public String toStringMultiLineMinimalNull() {
        char spaceChar = ' ';
        char topChar = '|';
        char leftChar = '┌';
        char rightChar = '┐';
        char middleChar = '─';
        char upChar = '┴';

        StringBuffer out = new StringBuffer();

        LinkedList<LinkedList<E>> lines = getLevelsList();
        lines.add(new LinkedList<E>());

        if (hasLeft() || hasRight()) {
            // Get Max size of element
            int maxElementSize = String.valueOf((E)null).length();
            for (LinkedList<E> line : lines) {
                for (E item : line) {
                    maxElementSize = Math.max(maxElementSize, String.valueOf(item).length());
                }
            }
            maxElementSize += (maxElementSize + 1) % 2;

            int lineNumb = 0;
            int numbLines = lines.size();
            int maxElementsRow = (int) Math.pow(2, numbLines - 1);
            int maxStringLengthRow = maxElementsRow * maxElementSize + (maxElementsRow - 1);

            // Add nulls for last line
            for (int i = 0; i < maxElementsRow; i++) {
                lines.get(lines.size() - 1).add(null);
            }

            Integer minSpace = null;
            for (LinkedList<E> line : lines) {
                StringBuffer lineOut = new StringBuffer();
                StringBuilder lineAbove = new StringBuilder();

                int itemOn = 0;
                for (E item : line) {
                    StringBuilder itemString;

                    if (lineNumb != 0 && lines.get(lineNumb - 1).get(itemOn / 2) == null) {
                        itemString = new StringBuilder();
                    } else {
                        itemString = new StringBuilder(String.valueOf(item));
                    }

                    // Add spaces around to make it the same length
                    int itemStringSize = itemString.length();

                    if (itemStringSize < 0) itemStringSize = 0;

                    double half = (maxElementSize - itemStringSize) / 2.0;
                    int amountFront = (int) Math.floor(half);
                    int amountBack = (int) Math.ceil(half);

                    if (amountFront > 0) itemString.insert(0, multiplyChar(amountFront, spaceChar)); // Front
                    if (amountBack > 0) itemString.append(multiplyChar(amountBack, spaceChar)); // Back

                    int elementsInRow = (int) Math.pow(2, lineNumb);

                    int lineTotalSizeItems = line.size() * maxElementSize;
                    int lineTotalSpaceSize = maxStringLengthRow - lineTotalSizeItems;
                    double lineSpaceItem = (double) lineTotalSpaceSize / elementsInRow;
                    int lineSpaceFront = (int) Math.floor(lineSpaceItem / 2);
                    int lineSpaceBack = (int) Math.ceil(lineSpaceItem / 2);

                    if (elementsInRow == 1) {
                        lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize / 2, spaceChar) + topChar);
                    } else if (lineNumb != 0 && lines.get(lineNumb - 1).get(itemOn / 2) == null) {
                        lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize + lineSpaceBack, spaceChar));
                    } else {
                        addLineAbove(spaceChar, leftChar, rightChar, middleChar, upChar, maxElementSize, lineAbove, itemOn, lineSpaceFront, lineSpaceBack);
                    }
                    lineOut.append(multiplyChar(lineSpaceFront, ' ') + itemString + multiplyChar(lineSpaceBack, ' ')); // Remove

                    itemOn++;
                }

                out.append(lineAbove + "\n");
                out.append(lineOut + "\n");

                int spaceFrontThis = lineOut.indexOf(lineOut.toString().trim());
                if (minSpace == null) {
                    minSpace = spaceFrontThis;
                } else {
                    minSpace = Math.min(minSpace, spaceFrontThis);
                }

                lineNumb++;
            }

            if (out.length() > 0) out.deleteCharAt(out.length() - 1);

            StringBuilder outLessFrontSpace = new StringBuilder();

            Scanner scanner = new Scanner(out.toString());

            while (scanner.hasNext()) {
                outLessFrontSpace.append(scanner.nextLine().substring(minSpace) + '\n');
            }

            return outLessFrontSpace.toString();
        } else {
            return topChar + "\n" + getValue().toString();
        }
    }

    public String toStringMultiLineNoNull() {
        char spaceChar = ' ';
        char topChar = '|';
        char leftChar = '┌';
        char rightChar = '┐';
        char middleChar = '─';
        char upChar = '┴';
        char upLeft = '└';
        char upRight = '┘';

        StringBuffer out = new StringBuffer();

        LinkedList<LinkedList<E>> lines = getLevelsList();

        // Get Max size of element
        int maxElementSize = 0;
        for (LinkedList<E> line : lines) {
            for (E item: line) {
                maxElementSize = Math.max(maxElementSize, String.valueOf(item).length());
            }
        }
        maxElementSize += (maxElementSize+1)%2;

        int lineNumb = 0;
        int numbLines = lines.size();
        int maxElementsRow = (int) Math.pow(2,numbLines-1);
        int maxStringLengthRow = maxElementsRow*maxElementSize + (maxElementsRow-1);

        Integer minSpace = null;
        for (LinkedList<E> line : lines) {
            StringBuffer lineOut = new StringBuffer();
            StringBuilder lineAbove = new StringBuilder();

            int itemOn = 0;
            for (E item: line) {
                StringBuilder itemString;

                if (lineNumb != 0 && item == null) {
                    itemString = new StringBuilder();
                }else {
                    itemString = new StringBuilder(String.valueOf(item));
                }

                // Add spaces around to make it the same length
                int itemStringSize = itemString.length();

                double half = (maxElementSize-itemStringSize)/2.0;
                int amountFront = (int) Math.floor(half);
                int amountBack = (int) Math.ceil(half);

                itemString.insert(0,multiplyChar(amountFront, spaceChar)); // Front
                itemString.append(multiplyChar(amountBack, spaceChar)); // Back

                int elementsInRow = (int) Math.pow(2, lineNumb);

                int lineTotalSizeItems = line.size()*maxElementSize;
                int lineTotalSpaceSize = maxStringLengthRow-lineTotalSizeItems;
                double lineSpaceItem = (double)lineTotalSpaceSize/elementsInRow;
                int lineSpaceFront = (int)Math.floor(lineSpaceItem/2);
                int lineSpaceBack = (int)Math.ceil(lineSpaceItem/2);

                if (elementsInRow == 1) {
                    lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize/2, spaceChar) + topChar);
                } else if (lineNumb != 0 && lines.get(lineNumb-1).get(itemOn/2) == null) {
                    lineAbove.append(multiplyChar(lineSpaceFront+maxElementSize+lineSpaceBack,spaceChar));
                } else {
                    if (itemOn%2 == 0){ // Left
                        // Add spaces for Left
                        if (item != null) {
                            addLineAbove(spaceChar, leftChar, rightChar, middleChar, upChar, maxElementSize, lineAbove, itemOn, lineSpaceFront, lineSpaceBack);
                            if (line.get(itemOn+1) == null) {
                                lineAbove.replace(lineAbove.length()-1, lineAbove.length(), String.valueOf(upRight));
                            }
                        } else {
                            lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize + lineSpaceBack-1, spaceChar));
                            if (line.get(itemOn+1) == null) {
                                lineAbove.append(spaceChar);
                            } else {
                                lineAbove.append(upLeft);
                            }
                        }

                    } else { // Right
                        if (item != null) {
                            lineAbove.append(multiplyChar(lineSpaceFront + (int) Math.ceil(maxElementSize/2), middleChar) + rightChar + multiplyChar(lineSpaceBack + maxElementSize/2, spaceChar));
                        } else {
                            lineAbove.append(multiplyChar(lineSpaceFront+maxElementSize+lineSpaceBack, spaceChar));
                        }
                    }
                }
                lineOut.append(multiplyChar(lineSpaceFront, ' ') + itemString + multiplyChar(lineSpaceBack, ' ')); // Remove

                itemOn++;
            }

            out.append(lineAbove + "\n");
            out.append(lineOut + "\n");

            int spaceFrontThis = lineOut.indexOf(lineOut.toString().trim());
            if (minSpace == null) {
                minSpace = spaceFrontThis;
            } else {
                minSpace = Math.min(minSpace, spaceFrontThis);
            }

            lineNumb++;
        }

        if (out.length() > 0) out.deleteCharAt(out.length()-1);

        StringBuilder outLessFrontSpace = new StringBuilder();

        Scanner scanner = new Scanner(out.toString());

        while (scanner.hasNext()) {
            outLessFrontSpace.append(scanner.nextLine().substring(minSpace) + '\n');
        }

        return outLessFrontSpace.toString();
    }

    private void addLineAbove(char spaceChar, char leftChar, char rightChar, char middleChar, char upChar, int maxElementSize, StringBuilder lineAbove, int itemOn, int lineSpaceFront, int lineSpaceBack) {
        if (itemOn%2 == 0){ // Left
            lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize/2, spaceChar) + leftChar + multiplyChar(lineSpaceBack + (int) Math.floor(maxElementSize/2)-1, middleChar) + upChar);
        } else { // Right
            lineAbove.append(multiplyChar(lineSpaceFront + (int) Math.ceil(maxElementSize/2), middleChar) + rightChar + multiplyChar(lineSpaceBack + maxElementSize/2, spaceChar));
        }
    }

    // General
    private boolean has(BinaryTreeNodeOld<E> item) {
        return item != null;
    }

    public BinaryTreeOldNew<E> get(BinaryTreeNodeOld<E> item) {
        return new BinaryTreeOldNew<E>(item);
    }

    public BinaryTreeNodeOld<E> getSetChild(E item) {
        return new BinaryTreeNodeOld<E>(getRoot(), item, null, null);
    }

    public BinaryTreeNodeOld<E> getSetChild(BinaryTreeOldNew item) {
        item.setParent(this);
        return item.getRoot();
    }

    public int getHeight() {
        int leftLength = 0;
        int rightLength = 0;

        if (hasLeft()) {
            leftLength = getLeft().getHeight();
        }
        if (hasRight()) {
            rightLength = getRight().getHeight();
        }

        return Math.max(leftLength,rightLength)+1;
    }

    private String multiplyChar(int amount, char character) {
        return new String(new char[amount]).replace("\0", String.valueOf(character));
    }

    // Get Order
    public LinkedList<LinkedList<E>> getLevelsList() {
        LinkedList<LinkedList<E>> out = new LinkedList<>();

        Queue<BinaryTreeOldNew<E>> currQ = new LinkedList<>();
        Queue<BinaryTreeOldNew<E>> nextQ = new LinkedList<>();
        LinkedList<E> currentLayer = new LinkedList<>();

        currQ.add(this);

        while (currQ.size() > 0 || nextQ.size() > 0) {

            BinaryTreeOldNew<E> headOn = currQ.poll();

            if (headOn == null) {
                currentLayer.add(null);
            } else {
                currentLayer.add(headOn.getValue());
            }


            if (headOn != null && headOn.hasLeft()) {
                nextQ.add(headOn.getLeft());
            } else {
                nextQ.add(null);
            }

            if (headOn != null && headOn.hasRight()) {
                nextQ.add(headOn.getRight());
            } else {
                nextQ.add(null);
            }

            if (currQ.size() == 0) {
                for (E currentValue : currentLayer) {
                    if (currentValue != null) {
                        currQ = nextQ;
                        nextQ = new LinkedList<>();
                        out.add(currentLayer);
                        currentLayer = new LinkedList<>();
                        break;
                    }
                }
                if (!currentLayer.isEmpty()) {
                    return out;
                }

            }
        }

        return out;
    }

    // Parent
    public boolean hasParent() {
        return getRoot().getParent() != null;
    }

    public BinaryTreeOldNew<E> getParent() {
        return get(getRoot().getParent());
    }

    public void setParent(BinaryTreeNodeOld<E> parent) {
        getRoot().setParent(parent);
    }

    public void setParent(BinaryTreeOldNew parent) {
        if (parent != null && parent.hasRoot() && hasRoot())
            setParent(parent.getRoot());
        else
            setParent((BinaryTreeNodeOld<E>) null);
    }

    // Root
    protected void setRoot(BinaryTreeNodeOld<E> root) {
        this.root = root;
    }


    public BinaryTreeNodeOld<E> getRoot() {
        return root;
    }

    public boolean hasRoot() {
        return getRoot() != null && getRoot().get() != null;
    }

    public E getValue() {
        return getRoot().get();
    }

    protected void setRoot(BinaryTreeOldNew<E> root) {
        setRoot(root.getRoot());
        getRoot().setParent(null);
    }

    protected void setRoot(E root) {
        if (hasRoot())
            setRoot(new BinaryTreeNodeOld<E>(getParent().getRoot(), root, null, null));
        else
            setRoot(new BinaryTreeNodeOld<E>((BinaryTreeOldNew<E>) null, root, null, null));
    }

    // Child
    public boolean isChild(BinaryTreeOldNew child) {
        return getLeft().getRoot() == child.getRoot() || getRight().getRoot() == child.getRoot();
    }

    // Left
    public boolean isLeftChild() {
        return hasParent() && getParent().hasLeft() && getParent().getLeft().getRoot() == getRoot();
    }

    public boolean hasLeft() {
        return has(getRoot().getLeft());
    }

    public BinaryTreeOldNew<E> getLeft() {
        return get(getRoot().getLeft());
    }

    public void setLeft(E item) {
        getRoot().setLeft(getSetChild(item));
    }

    public void setLeft(BinaryTreeOldNew item) {
        getRoot().setLeft(getSetChild(item));
    }

    public void leftRotate() {
        BinaryTreeOldNew<E> rightChild = getRight();

        rightChild.setParent(getParent());

        setRight(rightChild.getLeft());

        rightChild.setLeft(this);

        setRoot(rightChild);
    }


    // Right
    public boolean hasRight() {
        return has(getRoot().getRight());
    }

    public BinaryTreeOldNew<E> getRight() {
        return get(getRoot().getRight());
    }

    public void setRight(E item) {
        getRoot().setRight(getSetChild(item));
    }

    public void setRight(BinaryTreeOldNew item) {
        getRoot().setRight(getSetChild(item));
    }

    public void rightRotate() {
        BinaryTreeOldNew<E> leftChild = getLeft();

        leftChild.setParent(getParent());

        setLeft(leftChild.getRight());

        leftChild.setRight(this);

        setRoot(leftChild);
    }

    public static void main(String[] args) {
        BinaryTreeOldNew<Integer> tree = new BinaryTreeOldNew<Integer>(5);
        tree.setLeft(10);
        System.out.println(tree);
    }
}
*/
