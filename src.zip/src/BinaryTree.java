import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class BinaryTree<E> {
    TreeNode<E> root;

    public BinaryTree(BinaryTreeNode<E> root) {
        setRoot(root);
    }

    public BinaryTree() {
        this(new BinaryTreeNode<>(null, null,null,null));
    }
    public BinaryTree(E value, BinaryTreeNode<E> parent) {
        this(new BinaryTreeNode<E>(value,parent, null, null));
    }
    public BinaryTree(E value) {
        this(new BinaryTreeNode<E>(value,null, null, null));
    }

    // Root
    public void setRoot(BinaryTreeNode<E> root) {
        this.root = root;
    }
    public void setRoot(E value) {
        if (hasRoot())
            root.setValue(value);
        else
            setRoot(new BinaryTreeNode<E>(value,null,null,null));
    }
    public TreeNode getRootNode() {
        return root;
    }
    public boolean hasRoot() {
        return root != null && hasValue();
    }

    // Parent
    public TreeNode<E> getParentNode() {
        return root.getParent();
    }
    public BinaryTree<E> getParent() {
        return new BinaryTree<E>((BinaryTreeNode<E>) getParentNode());
    }
    public boolean hasParent() {
        return getParentNode() != null;
    }

    public void setParent(BinaryTreeNode<E> node) {
        if (hasParent()) {
            if (isLeftChild()) {
                getParent().setLeft(node);
            } else {
                System.out.println("setting");
                getParent().setRight(node);
            }
        }
    }

    // Value
    public void setValue(E value) {
        root.setValue(value);
    }
    public E getValue() {
        return root.getValue();
    }
    public String getValuePrintString() {
            return hasRoot() ? String.valueOf(getValue()) : String.valueOf((E) null);
    }
    public boolean hasValue() {
        return root.getValue() != null;
    }

    // Left
    public BinaryTree<E> setLeft(TreeNode<E> left) {
        if (left != null) left.setParent(root);
        getRootNode().setLeft(left);
        return getLeft();
    }

    public BinaryTree<E> setLeft(E value) {
        return setLeft(new BinaryTreeNode<>(value));
    }

    public TreeNode<E> getLeftNode() {
        return root.getLeft();
    }
    public BinaryTree<E> getLeft() {
        return new BinaryTree<E>((BinaryTreeNode<E>) getLeftNode());
    }
    public boolean hasLeft() {
        return getLeftNode() != null;
    }

    public boolean isLeftChild() {
        return hasParent() && getParent().hasLeft() && getParent().getLeftNode() == getRootNode();
    }

    public void leftRotate() {
        //System.out.println(this);
        BinaryTreeNode<E> rightChild = (BinaryTreeNode<E>) getRightNode();
        BinaryTreeNode<E> originalRoot = (BinaryTreeNode<E>) getRootNode();

        setParent(rightChild);
        //System.out.println(getParent());

        originalRoot.setRight(rightChild.getLeft());
        rightChild.setLeft(originalRoot);

        setRoot(rightChild);
    }

    // Right
    public BinaryTree<E> setRight(TreeNode<E> right) {
        if (right != null) right.setParent(root);
        getRootNode().setRight(right);
        return getRight();
    }
    public BinaryTree<E> setRight(E value) {
        return setRight(new BinaryTreeNode<>(value));
    }
    public TreeNode<E> getRightNode() {
        return root.getRight();
    }
    public BinaryTree<E> getRight() {
        return new BinaryTree<E>((BinaryTreeNode<E>) getRightNode());
    }
    public boolean hasRight() {
        return getRightNode() != null;
    }

    public boolean isRightChild() {
        return hasParent() && getParent().hasRight() && getParent().getRightNode() == getRootNode();
    }

    public void rightRotate() {
        //System.out.println(this);
        BinaryTreeNode<E> leftChild = (BinaryTreeNode<E>) getLeftNode();
        BinaryTreeNode<E> originalRoot = (BinaryTreeNode<E>) getRootNode();

        setParent(leftChild);
        //System.out.println(getParent());

        originalRoot.setLeft(leftChild.getRight());
        leftChild.setRight(originalRoot);

        setRoot(leftChild);
    }

    // Child
    public boolean isChild(BinaryTree child) {
        return getLeftNode() == child.getRootNode() || getRightNode() == child.getRootNode();
    }

    public int getMaxElementSizeCharacters() {
        LinkedList<LinkedList<BinaryTree<E>>> lines = getLevelsList();
        // Get Max size of element
        int maxElementSize = 0;
        for (LinkedList<BinaryTree<E>> line : lines) {
            for (BinaryTree<E> item: line) {
                if (item != null)
                    maxElementSize = Math.max(maxElementSize, item.getValuePrintString().length());
                else
                    maxElementSize = Math.max(maxElementSize, String.valueOf((E)null).length());
            }
        }
        maxElementSize += (maxElementSize+1)%2;
        return maxElementSize;
    }

    public String toString() {
        return toStringMultiLineMinimalNull();
    }

    public String toStringOneLine() {
        String out = "";
        // Has Root
        if (hasRoot()) {
            // This data
            out += getValue();

            // if leaf node, then return
            if (!hasLeft() && !hasRight())
                return out;

            // for left subtree
            out += '(';
            out += getLeft().getValuePrintString();
            out += ')';

            // Right subtree
            out += '(';
            out += getRight().getValuePrintString();
            out += ')';
        }
        return out;
    }

    public String toStringMultiLine() {
        char spaceChar = ' ';
        char topChar = '|';
        char leftChar = '┌';
        char rightChar = '┐';
        char middleChar = '─';
        char upChar = '┴';

        StringBuffer out = new StringBuffer();

        LinkedList<LinkedList<BinaryTree<E>>> lines = getLevelsList();

        // Get Max size of element
        int maxElementSize = getMaxElementSizeCharacters();

        int lineNumb = 0;
        int numbLines = lines.size();
        int maxElementsRow = (int) Math.pow(2,numbLines-1);
        int maxStringLengthRow = maxElementsRow*maxElementSize + (maxElementsRow-1);

        for (LinkedList<BinaryTree<E>> line : lines) {
            StringBuffer lineOut = new StringBuffer();
            StringBuilder lineAbove = new StringBuilder();

            int itemOn = 0;
            for (BinaryTree<E> item: line) {
                StringBuilder itemString = (item != null) ? new StringBuilder(item.getValuePrintString()) : new StringBuilder(String.valueOf((E) null));


                // Add spaces around to make it the same length
                int itemStringSize = itemString.length();

                double half = (maxElementSize-itemStringSize)/2.0;
                int amountFront = (int) Math.floor(half);
                int amountBack = (int) Math.ceil(half);

                itemString.insert(0,multiplyChar(amountFront, spaceChar)); // Front
                itemString.append(multiplyChar(amountBack, spaceChar)); // Back

                int elementsInRow = (int) Math.pow(2, lineNumb);

                int lineTotalSizeItems = line.size()*maxElementSize;
                int lineTotalSpaceSize = maxStringLengthRow-lineTotalSizeItems;
                double lineSpaceItem = (double)lineTotalSpaceSize/elementsInRow;
                int lineSpaceFront = (int)Math.floor(lineSpaceItem/2);
                int lineSpaceBack = (int)Math.ceil(lineSpaceItem/2);

                if (elementsInRow == 1) {
                    lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize/2, spaceChar) + topChar);
                } else
                    addLineAbove(spaceChar, leftChar, rightChar, middleChar, upChar, maxElementSize, lineAbove, itemOn, lineSpaceFront, lineSpaceBack);

                lineOut.append(multiplyChar(lineSpaceFront, ' ') + itemString + multiplyChar(lineSpaceBack, ' ')); // Remove

                itemOn++;
            }

            out.append(lineAbove + "\n");
            out.append(lineOut + "\n");
            lineNumb++;
        }

        if (out.length() > 0) out.deleteCharAt(out.length()-1);
        return out.toString();
    }

    public String toStringMultiLineMinimalNull() {
        char spaceChar = ' ';
        char topChar = '|';
        char leftChar = '┌';
        char rightChar = '┐';
        char middleChar = '─';
        char upChar = '┴';

        StringBuffer out = new StringBuffer();

        LinkedList<LinkedList<BinaryTree<E>>> lines = getLevelsList();
        lines.add((LinkedList<BinaryTree<E>>) new LinkedList<E>());

        if (hasLeft() || hasRight()) {
            // Get Max size of element
            int maxElementSize = getMaxElementSizeCharacters();

            int lineNumb = 0;
            int numbLines = lines.size();
            int maxElementsRow = (int) Math.pow(2, numbLines - 1);
            int maxStringLengthRow = maxElementsRow * maxElementSize + (maxElementsRow - 1);

            // Add nulls for last line
            for (int i = 0; i < maxElementsRow; i++) {
                lines.get(lines.size() - 1).add(null);
            }

            Integer minSpace = null;
            for (LinkedList<BinaryTree<E>> line : lines) {
                StringBuffer lineOut = new StringBuffer();
                StringBuilder lineAbove = new StringBuilder();

                int itemOn = 0;
                for (BinaryTree<E> item : line) {
                    StringBuilder itemString;

                    if (lineNumb != 0 && lines.get(lineNumb - 1).get(itemOn / 2) == null) {
                        itemString = new StringBuilder();
                    } else {
                        itemString = (item != null) ? new StringBuilder(item.getValuePrintString()) : new StringBuilder(String.valueOf((E) null));
                    }

                    // Add spaces around to make it the same length
                    int itemStringSize = itemString.length();

                    if (itemStringSize < 0) itemStringSize = 0;

                    double half = (maxElementSize - itemStringSize) / 2.0;
                    int amountFront = (int) Math.floor(half);
                    int amountBack = (int) Math.ceil(half);

                    if (amountFront > 0) itemString.insert(0, multiplyChar(amountFront, spaceChar)); // Front
                    if (amountBack > 0) itemString.append(multiplyChar(amountBack, spaceChar)); // Back

                    int elementsInRow = (int) Math.pow(2, lineNumb);

                    int lineTotalSizeItems = line.size() * maxElementSize;
                    int lineTotalSpaceSize = maxStringLengthRow - lineTotalSizeItems;
                    double lineSpaceItem = (double) lineTotalSpaceSize / elementsInRow;
                    int lineSpaceFront = (int) Math.floor(lineSpaceItem / 2);
                    int lineSpaceBack = (int) Math.ceil(lineSpaceItem / 2);

                    if (elementsInRow == 1) {
                        lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize / 2, spaceChar) + topChar);
                    } else if (lineNumb != 0 && lines.get(lineNumb - 1).get(itemOn / 2) == null) {
                        lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize + lineSpaceBack, spaceChar));
                    } else {
                        addLineAbove(spaceChar, leftChar, rightChar, middleChar, upChar, maxElementSize, lineAbove, itemOn, lineSpaceFront, lineSpaceBack);
                    }
                    lineOut.append(multiplyChar(lineSpaceFront, ' ') + itemString + multiplyChar(lineSpaceBack, ' ')); // Remove

                    itemOn++;
                }

                out.append(lineAbove + "\n");
                out.append(lineOut + "\n");

                int spaceFrontThis = lineOut.indexOf(lineOut.toString().trim());
                if (minSpace == null) {
                    minSpace = spaceFrontThis;
                } else {
                    minSpace = Math.min(minSpace, spaceFrontThis);
                }

                lineNumb++;
            }

            if (out.length() > 0) out.deleteCharAt(out.length() - 1);

            StringBuilder outLessFrontSpace = new StringBuilder();

            Scanner scanner = new Scanner(out.toString());

            while (scanner.hasNext()) {
                outLessFrontSpace.append(scanner.nextLine().substring(minSpace) + '\n');
            }

            return outLessFrontSpace.toString();
        } else {
            return topChar + "\n" + getValue().toString();
        }
    }

    public String toStringMultiLineNoNull() {
        char spaceChar = ' ';
        char topChar = '|';
        char leftChar = '┌';
        char rightChar = '┐';
        char middleChar = '─';
        char upChar = '┴';
        char upLeft = '└';
        char upRight = '┘';

        StringBuffer out = new StringBuffer();

        LinkedList<LinkedList<BinaryTree<E>>> lines = getLevelsList();

        // Get Max size of element
        int maxElementSize = getMaxElementSizeCharacters();

        int lineNumb = 0;
        int numbLines = lines.size();
        int maxElementsRow = (int) Math.pow(2,numbLines-1);
        int maxStringLengthRow = maxElementsRow*maxElementSize + (maxElementsRow-1);

        Integer minSpace = null;
        for (LinkedList<BinaryTree<E>> line : lines) {
            StringBuffer lineOut = new StringBuffer();
            StringBuilder lineAbove = new StringBuilder();

            int itemOn = 0;
            for (BinaryTree<E> item: line) {
                StringBuilder itemString;

                if (lineNumb != 0 && item == null) {
                    itemString = new StringBuilder();
                }else {
                    itemString = (item != null) ? new StringBuilder(item.getValuePrintString()) : new StringBuilder(String.valueOf((E) null));
                }

                // Add spaces around to make it the same length
                int itemStringSize = itemString.length();

                double half = (maxElementSize-itemStringSize)/2.0;
                int amountFront = (int) Math.floor(half);
                int amountBack = (int) Math.ceil(half);

                itemString.insert(0,multiplyChar(amountFront, spaceChar)); // Front
                itemString.append(multiplyChar(amountBack, spaceChar)); // Back

                int elementsInRow = (int) Math.pow(2, lineNumb);

                int lineTotalSizeItems = line.size()*maxElementSize;
                int lineTotalSpaceSize = maxStringLengthRow-lineTotalSizeItems;
                double lineSpaceItem = (double)lineTotalSpaceSize/elementsInRow;
                int lineSpaceFront = (int)Math.floor(lineSpaceItem/2);
                int lineSpaceBack = (int)Math.ceil(lineSpaceItem/2);

                if (elementsInRow == 1) {
                    lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize/2, spaceChar) + topChar);
                } else if (lineNumb != 0 && lines.get(lineNumb-1).get(itemOn/2) == null) {
                    lineAbove.append(multiplyChar(lineSpaceFront+maxElementSize+lineSpaceBack,spaceChar));
                } else {
                    if (itemOn%2 == 0){ // Left
                        // Add spaces for Left
                        if (item != null) {
                            addLineAbove(spaceChar, leftChar, rightChar, middleChar, upChar, maxElementSize, lineAbove, itemOn, lineSpaceFront, lineSpaceBack);
                            if (line.get(itemOn+1) == null) {
                                lineAbove.replace(lineAbove.length()-1, lineAbove.length(), String.valueOf(upRight));
                            }
                        } else {
                            lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize + lineSpaceBack-1, spaceChar));
                            if (line.get(itemOn+1) == null) {
                                lineAbove.append(spaceChar);
                            } else {
                                lineAbove.append(upLeft);
                            }
                        }

                    } else { // Right
                        if (item != null) {
                            lineAbove.append(multiplyChar(lineSpaceFront + (int) Math.ceil(maxElementSize/2), middleChar) + rightChar + multiplyChar(lineSpaceBack + maxElementSize/2, spaceChar));
                        } else {
                            lineAbove.append(multiplyChar(lineSpaceFront+maxElementSize+lineSpaceBack, spaceChar));
                        }
                    }
                }
                lineOut.append(multiplyChar(lineSpaceFront, ' ') + itemString + multiplyChar(lineSpaceBack, ' ')); // Remove

                itemOn++;
            }

            out.append(lineAbove + "\n");
            out.append(lineOut + "\n");

            int spaceFrontThis = lineOut.indexOf(lineOut.toString().trim());
            if (minSpace == null) {
                minSpace = spaceFrontThis;
            } else {
                minSpace = Math.min(minSpace, spaceFrontThis);
            }

            lineNumb++;
        }

        if (out.length() > 0) out.deleteCharAt(out.length()-1);

        StringBuilder outLessFrontSpace = new StringBuilder();

        Scanner scanner = new Scanner(out.toString());

        while (scanner.hasNext()) {
            outLessFrontSpace.append(scanner.nextLine().substring(minSpace) + '\n');
        }

        return outLessFrontSpace.toString();
    }

    private void addLineAbove(char spaceChar, char leftChar, char rightChar, char middleChar, char upChar, int maxElementSize, StringBuilder lineAbove, int itemOn, int lineSpaceFront, int lineSpaceBack) {
        if (itemOn%2 == 0){ // Left
            lineAbove.append(multiplyChar(lineSpaceFront + maxElementSize/2, spaceChar) + leftChar + multiplyChar(lineSpaceBack + (int) Math.floor(maxElementSize/2)-1, middleChar) + upChar);
        } else { // Right
            lineAbove.append(multiplyChar(lineSpaceFront + (int) Math.ceil(maxElementSize/2), middleChar) + rightChar + multiplyChar(lineSpaceBack + maxElementSize/2, spaceChar));
        }
    }

    private String multiplyChar(int amount, char character) {
        return new String(new char[amount]).replace("\0", String.valueOf(character));
    }

    // Get Order
    public LinkedList<LinkedList<E>> getLevelsListValues() {
        LinkedList<LinkedList<E>> out = new LinkedList<>();

        Queue<BinaryTree<E>> currQ = new LinkedList<>();
        Queue<BinaryTree<E>> nextQ = new LinkedList<>();
        LinkedList<E> currentLayer = new LinkedList<>();

        currQ.add(this);

        while (currQ.size() > 0 || nextQ.size() > 0) {

            BinaryTree<E> headOn = currQ.poll();

            if (headOn == null) {
                currentLayer.add(null);
            } else {
                currentLayer.add(headOn.getValue());
            }


            if (headOn != null && headOn.hasLeft()) {
                nextQ.add(headOn.getLeft());
            } else {
                nextQ.add(null);
            }

            if (headOn != null && headOn.hasRight()) {
                nextQ.add(headOn.getRight());
            } else {
                nextQ.add(null);
            }

            if (currQ.size() == 0) {
                for (E currentValue : currentLayer) {
                    if (currentValue != null) {
                        currQ = nextQ;
                        nextQ = new LinkedList<>();
                        out.add(currentLayer);
                        currentLayer = new LinkedList<>();
                        break;
                    }
                }
                if (!currentLayer.isEmpty()) {
                    return out;
                }

            }
        }

        return out;
    }

    public LinkedList<LinkedList<BinaryTree<E>>> getLevelsList() {
        LinkedList<LinkedList<BinaryTree<E>>> out = new LinkedList<>();

        Queue<BinaryTree<E>> currQ = new LinkedList<>();
        Queue<BinaryTree<E>> nextQ = new LinkedList<>();
        LinkedList<BinaryTree<E>> currentLayer = new LinkedList<>();

        currQ.add(this);

        while (currQ.size() > 0 || nextQ.size() > 0) {

            BinaryTree<E> headOn = currQ.poll();

            if (headOn == null) {
                currentLayer.add(null);
            } else {
                currentLayer.add(headOn);
            }


            if (headOn != null && headOn.hasLeft()) {
                nextQ.add(headOn.getLeft());
            } else {
                nextQ.add(null);
            }

            if (headOn != null && headOn.hasRight()) {
                nextQ.add(headOn.getRight());
            } else {
                nextQ.add(null);
            }

            if (currQ.size() == 0) {
                for (BinaryTree<E> currentValue : currentLayer) {
                    if (currentValue != null && currentValue.hasValue()) {
                        currQ = nextQ;
                        nextQ = new LinkedList<>();
                        out.add(currentLayer);
                        currentLayer = new LinkedList<>();
                        break;
                    }
                }
                if (!currentLayer.isEmpty()) {
                    return out;
                }

            }
        }

        return out;
    }

    public static void main(String[] args) {
        BinaryTree<Integer> tree = new BinaryTree<>(5);
        tree.setLeft(5);
        System.out.println(tree.getLeft().isLeftChild());
    }
}
