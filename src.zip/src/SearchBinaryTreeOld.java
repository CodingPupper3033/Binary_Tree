import java.util.NoSuchElementException;

public class SearchBinaryTreeOld<E extends Comparable> extends BinaryTreeOld<E> {
    public SearchBinaryTreeOld() {
    }
    public SearchBinaryTreeOld(E rootData) {
        super(rootData);
    }

    public SearchBinaryTreeOld(BinaryTreeOld root) {
        super(root);
    }

    public void add(E data) {
        BinaryTreeOld y = null;
        BinaryTreeOld x = getTree();

        while (x != null && x.getNoError() != null) {
            y = x;
            try {
                if (data.compareTo(x.get()) < 0) {
                    x = x.getTreeLeft();
                } else {
                    x = x.getTreeRight();
                }
            } catch (NoSuchElementException e) {
                x = null;
            }
        }

        if (y == null) {
            setRoot(data);
        } else if (data.compareTo(y.get()) < 0) {
            y.setLeft(data);
        } else {
            y.setRight(data);
        }
    }

    public SearchBinaryTreeOld<E> getNext(E root) {
        if (root.equals(get())) {
            return this;
        } else if (root.compareTo(get()) < 0) {
            return new SearchBinaryTreeOld<E>(getTreeLeft());
        } else {
            return new SearchBinaryTreeOld<E>(getTreeRight());
        }
    }

    public SearchBinaryTreeOld<E> getTree(E root) {
        if (root.equals(get())) {
            return this;
        } else {
            return getNext(root).getTree(root);
        }
    }

    // No clue what happens with duplicates
    public SearchBinaryTreeOld<E> getTreeParent(E child){
        if (get().equals(child)) throw new NoSuchElementException("Root has no parent");
        if ((hasLeft() && getLeft().equals(child)) || (hasRight() && getRight().equals(child))) {
            return this;
        } else {
            return getNext(child).getTreeParent(child);
        }
    }

    public E getMinimum() {
        if (hasLeft()) {
            return new SearchBinaryTreeOld<E>(getTreeLeft()).getMinimum();
        } else {
            return get();
        }
    }

    public E getMaximum() {
        if (hasRight()) {
            return new SearchBinaryTreeOld<E>(getTreeRight()).getMaximum();
        } else {
            return get();
        }
    }

    private void transplant(E item, E replacer) {
        BinaryTreeOld<E> itemTree = getTree(item);
        BinaryTreeOld<E> replacerTree;

        try {
            if (itemTree.get().equals(replacer)) {
                replacerTree = new SearchBinaryTreeOld<E>(itemTree.getTreeRight()).getTree(replacer);
            } else {
                replacerTree = getTree(replacer);
            }
        } catch (NoSuchElementException | NullPointerException e){
            replacerTree = null;
        }

        if (!itemTree.hasParent()) { // No Parent
            if (replacerTree != null) {
                setRoot(replacerTree);
            } else {
                deleteRoot();
            }
        } else if (itemTree.isLeftChild(replacer)) { // Is the Left Child
            if (replacerTree != null) {
                itemTree.getParent().setLeft(replacerTree);
            } else {
                itemTree.getParent().deleteLeft();
            }
        } else {
            if (replacerTree != null) {
                itemTree.getParent().setRight(replacerTree);
            } else {
                itemTree.getParent().deleteRight();
            }
        }
    }

    public void delete(E item) {
        BinaryTreeOld<E> itemTree = getTree(item);

        if (!itemTree.hasLeft()) { // No left child
            System.out.println("No Left Child");
            transplant(item, itemTree.getRightNoError());
        } else if (!itemTree.hasRight()) { // No right child
            System.out.println("No Right Child");
            transplant(item, itemTree.getLeftNoError());
        }
    }

    public static void main(String[] args) {
        SearchBinaryTreeOld<Integer> tree = new SearchBinaryTreeOld<>();

        tree.add(5);
        tree.add(2);
        tree.add(3);
        tree.add(1);
        tree.add(6);
        tree.add(10);
        tree.add(9);
        tree.delete(10);

        //System.out.println(tree.getTreeParent(10).get());
        System.out.println();
    }
}
