import java.awt.*;
import java.sql.SQLOutput;
import java.util.LinkedList;

public class RBTree<E extends Comparable> extends BinarySearchTree<E>{

    public RBTree(RBTreeNode<E> root) {
        setRoot(root);
    }

    public RBTree() {
        this(new RBTreeNode<>(null, null,null,null));
    }
    public RBTree(E value, RBTreeNode<E> parent) {
        this(new RBTreeNode<E>(value,parent, null, null));
    }
    public RBTree(E value) {
        this(new RBTreeNode<E>(value,null, null, null));
    }

    // Value
    public String getValuePrintString() {
        return hasRoot() ? String.valueOf("{" + getValue() + " : " + (isRed() ? "R": "B") + "}") : String.valueOf((E) null);
    }

    // Root
    public void setRoot(RBTreeNode<E> root) {
        this.root = root;
    }
    public void setRoot(E value) {
        if (hasRoot())
            root.setValue(value);
        else
            setRoot(new RBTreeNode<>(value,null,null,null));
    }

    // Parent
    public RBTree<E> getParent() {
        return new RBTree<>((RBTreeNode<E>) getParentNode());
    }
    public RBTree<E> getParentNil() {
        return hasParent() ? getParent() : new RBTreeNil<>();
    }

    public void setParent(RBTreeNode<E> node) {
        if (hasParent()) {
            if (isLeftChild()) {
                getParent().setLeft(node);
            } else {
                getParent().setRight(node);
            }
        }
    }

    // Left
    public RBTree setLeft(E value) {
        return (RBTree) setLeft(new RBTreeNode<>(value));
    }
    public RBTree<E> getLeft() {
        return new RBTree<E>((RBTreeNode<E>) getLeftNode());
    }
    public RBTree<E> getLeftNil() {
        return hasLeft() ? getLeft() : new RBTreeNil<>();
    }

    public void leftRotate() {
        //System.out.println(this);
        RBTreeNode<E> rightChild = (RBTreeNode<E>) getRightNode();
        RBTreeNode<E> originalRoot = (RBTreeNode<E>) getRootNode();

        setParent(rightChild);
        //System.out.println(getParent());

        originalRoot.setRight(rightChild.getLeft());
        rightChild.setLeft(originalRoot);

        setRoot(rightChild);
    }

    // Right
    public RBTree<E> setRight(E value) {
        return (RBTree<E>) setRight(new RBTreeNode<>(value));
    }
    public RBTree<E> getRight() {
        return new RBTree<E>((RBTreeNode<E>) getRightNode());
    }
    public RBTree<E> getRightNil() {
        return hasRight() ? getRight() : new RBTreeNil<>();
    }

    public void rightRotate() {
        //System.out.println(this);
        RBTreeNode<E> leftChild = (RBTreeNode<E>) getLeftNode();
        RBTreeNode<E> originalRoot = (RBTreeNode<E>) getRootNode();

        setParent(leftChild);
        //System.out.println(getParent());

        originalRoot.setLeft(leftChild.getRight());
        leftChild.setRight(originalRoot);

        setRoot(leftChild);
    }

    // Minimum
    public RBTree getMinimum() {
        if (hasLeft()) {
            return getLeft().getMinimum();
        } else {
            return this;
        }
    }

    // Color
    public boolean isRed() {
        return ((RBTreeNode<Integer>)getRootNode()).isRed();
    }

    @Deprecated
    public Color getColor() {
        return ((RBTreeNode<Integer>)getRootNode()).getColor();
    }

    public void setRed(boolean red) {
        ((RBTreeNode<Integer>)getRootNode()).setRed(red);
    }

    // Transplant & Delete
    public void transplant(BinaryTree<E> item, BinaryTree<E> replacer) {
        //System.out.println(item.hasParent());
        if (!item.hasParent()) {
            setRoot((RBTreeNode<E>) replacer.getRootNode());
        } else if (item.isLeftChild()) {
            item.getParent().setLeft(replacer.getRootNode());
        } else {
            item.getParent().setRight(replacer.getRootNode());
        }
    }

    // Insert
    @Override
    public RBTree<E> add(E object) {
        RBTree<E> tree = (RBTree<E>) super.add(object);
        insertFixup(tree);
        return tree;
    }


    public void insertFixup(RBTree<E> tree) {
        while (tree.getParentNil().isRed()) { // Line 1
            if (tree.isLeftChild()) {
                RBTree<E> uncle = tree.getParentNil().getParentNil().getRightNil();

                if (uncle.isRed()) {
                    tree.getParentNil().setRed(false);
                    uncle.setRed(false);
                    tree.getParentNil().getParentNil().setRed(true);
                    tree = tree.getParentNil().getParentNil();
                } else {
                    // TODO LEFT ONE

                    tree.getParentNil().setRed(false);
                    tree.getParentNil().getParentNil().setRed(true);
                    System.out.println("rotator\n" + tree.getParentNil().getParentNil());
                    tree.getParentNil().getParentNil().rightRotate();
                }
            }
        }
        setRed(false);
    }

    @Deprecated
    public static RBTree<Integer> createRandomTree(int maxN, int amount) {
        RBTree<Integer> tree = new RBTree<Integer>();
        for (int i = 0; i < amount; i++) {
            int numb = (int) (Math.random()*maxN);
            tree.add(numb);
        }
        return tree;
    }

    public static void main(String[] args) {
        RBTree<Integer> tree = new RBTree<Integer>();


        tree.add(10);
        //System.out.println(tree);

        tree.add(15);
        //System.out.println(tree);



        tree.add(5);
        //System.out.println(tree);



        tree.add(2);
        System.out.println(tree);

        tree.add(1);
        System.out.println(tree);

        tree.add(0);
        System.out.println(tree);

        tree.add(-1);
        System.out.println(tree);

        tree.add(-2);
        System.out.println(tree);


        //tree.rightRotate();
        //System.out.println(tree);



        /*
        int maxN = 100;
        int amount = 5;

        for (int i = 0; i < amount; i++) {
            int numb = (int) (Math.random()*maxN);
            tree.add(numb);
            System.out.println(((RBTreeNode<Integer>)tree.getTreeFromValue(numb).getRootNode()).getColor());
        }

         */

        //System.out.println(tree.toStringMultiLineNoNull());
    }
}

